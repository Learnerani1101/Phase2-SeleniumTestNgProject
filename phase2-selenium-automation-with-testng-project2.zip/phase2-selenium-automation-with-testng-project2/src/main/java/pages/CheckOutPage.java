package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckOutPage {
	WebDriver driver;
	WebDriverWait wait;

	public CheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}

	/*********************************************************************************
	 * Start CheckOut Process Click on the Checkout button. The user will be
	 * navigated to the checkout page
	 **********************************************************************************/
	@FindBy(xpath = "//a[contains(@href,'/order/checkout/')]")
	private WebElement elmChkOutBtn;

	public String navigateToCheckOut() throws InterruptedException {
		boolean isChkOutBtnDisplayed = elmChkOutBtn.isDisplayed();
		if (isChkOutBtnDisplayed) {
			wait.until(ExpectedConditions.elementToBeClickable(elmChkOutBtn));
			elmChkOutBtn.click();
		}
		Thread.sleep(Duration.ofSeconds(5));
		return driver.getCurrentUrl();
	}

	/*****************************************************************************************
	 * Validate UPI RadioButton is selected by default while completing payment for
	 * checkout:
	 *****************************************************************************************/
	@FindBy(xpath = "//input[@name='upi']")
	private WebElement elmUpiRadioBtn;

	public boolean isUPIBtnSelected() {
		boolean blockUPI = false;
		String[] reportUPIRadioStatus = new String[2];
		reportUPIRadioStatus = isUPIBtnSelected_V2(driver);
		if (reportUPIRadioStatus[0].equals("block")) {
			blockUPI = true;
		}
		return blockUPI;
	}

	public static String[] isUPIBtnSelected_V2(WebDriver driver) {
		String xpathUPIRadio = "(//i[@class='mt-4'])[1]";
		WebElement elmUPIRadio = driver.findElement(By.xpath(xpathUPIRadio));
		System.out.println("is elmUPIRadio displayed =" + elmUPIRadio.isDisplayed());
		// Retrieve the 'display' property of the ::after element to check if it's
		// present/visible
		String beforeDisplayStatusUPI = getPseudoElementContent(driver, elmUPIRadio, "::before", "display");
		String afterDisplayStatusUPI = getPseudoElementContent(driver, elmUPIRadio, "::after", "display");

		// Retrieve the 'content' property if the ::after element adds specific
		// text/icon
		String beforeContentUPI = getPseudoElementContent(driver, elmUPIRadio, "::before", "content");
		String afterContentUPI = getPseudoElementContent(driver, elmUPIRadio, "::after", "content");
		// Print display status and content for pseudo-element ::before and ::after
		//System.out.println("========Print display status and content for UPI Radio Button================");
		//System.out.println("beforeDisplayStatusUPI = " + beforeDisplayStatusUPI);
		//System.out.println("afterDisplayStatusUPI = " + afterDisplayStatusUPI);
		//System.out.println("beforeContentUPI = " + beforeContentUPI);
		//System.out.println("afterContentUPI = " + afterContentUPI);
		// return display status and content for reporting
		String[] statusUPIRadio = new String[2];
		statusUPIRadio[0] = afterDisplayStatusUPI;
		statusUPIRadio[1] = afterContentUPI;
		return statusUPIRadio;
	}

	/*****************************************************************************************
	 * Click Card Radio Button while completing payment for checkout:
	 *****************************************************************************************/
	@FindBy(xpath = "//label[@for='payment-method--razorpay/card']//div[@class='flex justify-between items-center flex-grow']")
	private WebElement elmCardRadioBtn;

	public boolean makePaymentWithCard() throws InterruptedException {
		boolean isCardOptionSelected = false;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		// Optional: Add a delay to observe the scroll action
		Thread.sleep(Duration.ofSeconds(5));
		String xpathCardRadio = "(//i[@class='mt-4'])[2]";
		WebElement elmCardRadio = driver.findElement(By.xpath(xpathCardRadio));
		//System.out.println("=======================Print Click Status of Card Radio before Clicking================");
		isCardBtnSelected(driver, elmCardRadio);
		boolean isCardSelected = elmCardRadioBtn.isSelected();
		//System.out.println("Before clicking Card Radio Button :: isCardSelected = " + isCardSelected);
		if (!isCardSelected) {
			wait.until(ExpectedConditions.elementToBeClickable(elmCardRadioBtn));
			// Thread.sleep(Duration.ofSeconds(2));
			elmCardRadioBtn.click();
		}
		Thread.sleep(Duration.ofSeconds(2));
		//System.out.println("=======================Print Click Status of Card Radio after Clicking================");
		String[] reportCardRadioStatus = new String[2];
		reportCardRadioStatus = isCardBtnSelected(driver, elmCardRadio);
		if (reportCardRadioStatus[0].equals("block")) {
			isCardOptionSelected = true;
		}
		return isCardOptionSelected;
	}
	/*************************************************************************************************
	 * Check If Card Radio Button is selected
	 *************************************************************************************************/
	public static String[] isCardBtnSelected(WebDriver driver, WebElement elmCardRadio) {
		// String xpathCardRadio = "(//i[@class='mt-4'])[2]";
		// WebElement elmCardRadio = driver.findElement(By.xpath(xpathCardRadio));
		System.out.println("is elmCardRadio displayed =" + elmCardRadio.isDisplayed());
		// Retrieve the 'display' property of the ::after element to check if it's
		// present/visible
		String beforeDisplayStatusCard = getPseudoElementContent(driver, elmCardRadio, "::before", "display");
		String afterDisplayStatusCard = getPseudoElementContent(driver, elmCardRadio, "::after", "display");
		// Retrieve the 'content' property if the ::after element adds specific
		// text/icon
		String beforeContentCard = getPseudoElementContent(driver, elmCardRadio, "::before", "content");
		String afterContentCard = getPseudoElementContent(driver, elmCardRadio, "::after", "content");
		//System.out.println("beforeDisplayStatusCard = " + beforeDisplayStatusCard);
		//System.out.println("afterDisplayStatusCard = " + afterDisplayStatusCard);
		//System.out.println("beforeContentCard = " + beforeContentCard);
		//System.out.println("afterContentCard = " + afterContentCard);
		// return display status and content for reporting
		String[] statusCardRadio = new String[2];
		statusCardRadio[0] = afterDisplayStatusCard;
		statusCardRadio[1] = afterContentCard;
		return statusCardRadio;
	}
	/**************************************************************************************************************
	 * Retrieve display status and content for pseudo-element ::before and ::after
	 * inside Radio button UPI and Card
	 ***************************************************************************************************************/

	public static String getPseudoElementContent(WebDriver driver, WebElement element, String pseudoElement,
			String property) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		String script = "return window.getComputedStyle(arguments[0], arguments[1]).getPropertyValue(arguments[2]);";
		return (String) jsExecutor.executeScript(script, element, pseudoElement, property);
	}

	/**************************************************************************************************************
	 * Validate "I Agree" CheckBox is selected by default in CheckOut Page
	 ***************************************************************************************************************/
	@FindBy(xpath = "//input[@name='marketingOptIn']")
	private WebElement elmIAgreeChkBox;

	public boolean checkIfIAgreeChkBoxSelected() {
		Boolean isIAgreeSelected = false;
		if (elmIAgreeChkBox.isSelected()) {
			isIAgreeSelected = true;
		}
		return isIAgreeSelected;
	}

	/**************************************************************************************************************
	 * //Enter name , phone and email
	 ***************************************************************************************************************/
	// Enter name , phone and email
	@FindBy(xpath = "//input[@id='checkout__name']")
	private WebElement elmNameTxt;

	@FindBy(xpath = "//input[@id='checkout__phone']")
	private WebElement elmPhoneTxt;

	@FindBy(xpath = "//input[@id='checkout__email']")
	private WebElement elmEmailTxt;

	public void enterCustomerInfoToChkOut(String customerName, String customerPhoneNum, String customerEmail) {
		// Enter name , phone and email
		wait.until(ExpectedConditions.elementToBeClickable(elmNameTxt));
		elmNameTxt.sendKeys(customerName);
		wait.until(ExpectedConditions.elementToBeClickable(elmPhoneTxt));
		elmPhoneTxt.sendKeys(customerPhoneNum);
		// driver.findElement(By.xpath(xpathPhoneTxt)).sendKeys("9876543210");
		wait.until(ExpectedConditions.elementToBeClickable(elmEmailTxt));
		elmEmailTxt.sendKeys(customerEmail);
		// driver.findElement(By.xpath(xpathEmailTxt)).sendKeys("TestEmail1@xyz.com");
	}
	/**************************************************************************************************************
	   get the customer name
	 ***************************************************************************************************************/
	public String getCustomerNameFromApp() {
		return elmNameTxt.getText();
	}
	/**************************************************************************************************************
	    get the CustomerPhoneNum
	 *****************************************************************************************************************/
	public String getCustomerPhoneNumFromApp() {
		return elmPhoneTxt.getText();
	}
	/**************************************************************************************************************
    get the CustomerEmail
	 *****************************************************************************************************************/
	public String getCustomerEmailFromApp() {
		return elmEmailTxt.getText();
	}
	/**************************************************************************************************************
	 * Click on Apply Gift Card and get URL of Gift Card Dialogue
	 ***************************************************************************************************************/
	@FindBy(xpath = "//button[@class='w-full']")
	private WebElement elmApplyGiftCardBtn;

	public String useGiftCard() throws InterruptedException {
		// Click on Apply Gift Card
		boolean isGiftCardVisible = elmApplyGiftCardBtn.isDisplayed();
		System.out.println("isGiftCardVisible =" + isGiftCardVisible);
		wait.until(ExpectedConditions.elementToBeClickable(elmApplyGiftCardBtn));
		elmApplyGiftCardBtn.click();
		// Validate if GiftCard Dilouge is loaded
		// GiftCard url=>
		// https://www.pizzahut.co.in/order/deals?showGiftCardModalV2=true
		String strToCheckinGiftCardURL = "showGiftCard";
		wait.until(ExpectedConditions.urlContains(strToCheckinGiftCardURL));
		Thread.sleep(Duration.ofSeconds(5));
		return driver.getCurrentUrl();
	}
	/**************************************************************************************************************
	 * Apply for Coupon
	 ***************************************************************************************************************/
	//Check default UI State for Gift Card and Coupon
	@FindBy(xpath ="//span[normalize-space()='Gift Card']")
	private WebElement elmGiftCard ;

	@FindBy(xpath ="//span[normalize-space()='Coupon']")
	private WebElement elmGiftCoupon ;

	@FindBy(xpath = "//input[@name='voucherId']")
	private WebElement elmCouponCodeTxt ;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement elmApplyCouponCodeBtn ;
	//Click on "Coupon"
	public String applyCoupon(String couponCode) throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(elmGiftCoupon));
		elmGiftCoupon.click();
		//Enter Coupon Code
		wait.until(ExpectedConditions.elementToBeClickable(elmCouponCodeTxt));
		elmCouponCodeTxt.sendKeys(couponCode);
		//Click on Apply Button
		wait.until(ExpectedConditions.elementToBeClickable(elmApplyCouponCodeBtn));
		elmApplyCouponCodeBtn.click();
		Thread.sleep(Duration.ofSeconds(5));
		String couponCodeErr = getErrDescForWrongCouponCode(driver,wait);
		closeVoucherPopUp(driver,wait);
		Thread.sleep(Duration.ofSeconds(5));
		return couponCodeErr;
	}
	/**************************************************************************************************************
	 * Get the Error description for wrong Coupon Code
	 ***************************************************************************************************************/
	//Get the Error description for wrong Coupon Code
	public static String getErrDescForWrongCouponCode(WebDriver driver,WebDriverWait wait) {		
		WebElement elmcouponCodeErrTxt = driver.findElement(By.cssSelector("div[class='sc-fznJRM ciBEcK'] span"));
		wait.until(ExpectedConditions.visibilityOf(elmcouponCodeErrTxt));
		return elmcouponCodeErrTxt.getText();		
	}
	/**************************************************************************************************************
	 * Close the voucher pop up
	 ***************************************************************************************************************/
	@FindBy(xpath = "//h2[.='Apply a Coupon code']/following-sibling::button")
	private static WebElement elmCloseGiftCardDilougeBtn ;
	public static void closeVoucherPopUp(WebDriver driver,WebDriverWait wait) {
		wait.until(ExpectedConditions.elementToBeClickable(elmCloseGiftCardDilougeBtn));
		elmCloseGiftCardDilougeBtn.click();		
	}


}
