package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.model.Test;

public class HomePage {
	WebDriver driver;
	WebDriverWait wait;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}

	// Verify if both Tab for Delivery is available
	@FindBy(xpath = "//span[normalize-space()='Collect From Store']")
	private WebElement elmTabCollectFromStore;

	@FindBy(xpath = "//span[normalize-space()='Delivery']")
	private WebElement elmTabDelivery;

	public boolean checkBothDeliveryTabIsPresent() {
		boolean ifBothDeliveryTabPresent = false;
		if (elmTabCollectFromStore.isEnabled() && elmTabDelivery.isEnabled()) {
			ifBothDeliveryTabPresent = true;
		}
		return ifBothDeliveryTabPresent;
	}

	// Enter Delivery Location
	@FindBy(xpath = "//input[@placeholder='Enter your location for delivery']")
	private WebElement elmLocationFinder;

	@FindBy(xpath = "//div[@class='flex flex-col']/button")
	private List<WebElement> resultLoc;
	
	@FindBy(xpath = "//body[contains(@class, 'ReactModal__Body')]")
	private WebElement elmModalBody;
	
	@FindBy(xpath = "//div[@class='pl-10 pr-10']/div[1]/img")
	private WebElement elmlocation ;
	
	@FindBy(xpath = "//div[@class='notification-container notification-container__basket']")
	private WebElement elmNote1 ;
	
	public void enterDeliveryLocation(String location) throws InterruptedException {
		WebElement elmDeliveryLocation = wait.until(ExpectedConditions.elementToBeClickable(elmLocationFinder));
		elmDeliveryLocation.sendKeys(location + Keys.SPACE);
		Thread.sleep(Duration.ofSeconds(5));
		// Verify Options for Delivery locations are available		
		wait.until(ExpectedConditions.visibilityOfAllElements(resultLoc));
		System.out.println("resultLoc Size = " + resultLoc.size());
		// Thread.sleep(Duration.ofSeconds(3));
		elmDeliveryLocation.sendKeys(Keys.ENTER);
		
		// ReactModal__Body--open
		// Wait for the modal or the list of options container to appear
		/**String xpathModal = "//body[contains(@class, 'ReactModal__Body')]";
		// WebElement elmContent =
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathModal)));
		**/
		wait.until(ExpectedConditions.visibilityOf(elmModalBody));
		String cssOptionsContainer = "div[class='pl-10 pr-10']";
		WebElement optionsContainer = wait.
			until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(cssOptionsContainer)));
		if (optionsContainer.isDisplayed()) {
			System.out.println("Options for location are displayed");
		} else {
			System.out.println("Options for location are not displayed");
		}
		
		// Select the Location from Modal Container
		//String xpathlocationToSelect = "//div[@class='pl-10 pr-10']/div[1]/img";
		//WebElement elmlocation = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathlocationToSelect)));
		wait.until(ExpectedConditions.elementToBeClickable(elmlocation));
		System.out.println("Check If location is enabled to select :: " + elmlocation.isEnabled());
		elmlocation.click();
		Thread.sleep(Duration.ofSeconds(5));
	}
	
	public String navigateOrderDealPage() {		
		/**
		 * If operations are conducted outside business hour then Notification will
		 * appear And User won't be able to place Order Checking if notification is
		 * present
		 **/
		String notificationTxt = "";
		String resultDealPageload = "";
		//String xpathElmNote = "//div[@class='notification-container notification-container__basket']";
		// div[class='notification-container notification-container__basket'] div
		//WebElement elmNote1 = driver.findElement(By.xpath(xpathElmNote));
		// List<WebElement> elmNote2 = driver.findElements(By.cssSelector
		// (".notification-container.notification-container__basket"));
		boolean isNotificationPresent = elmNote1.isDisplayed();
		System.out.println("Printing isNotificationPresent =  " + isNotificationPresent);
		if (isNotificationPresent) {
			WebElement elmNote = wait.until(ExpectedConditions.elementToBeClickable(
					By.cssSelector(".notification-container.notification-container__basket")));
			List<WebElement> childElements = elmNote.findElements(By.xpath("./*"));
			// Now have a List<WebElement> containing all children.
			System.out.println("Total child elements found: " + childElements.size());
			// Iterate through the list to interact with each child element
			for (WebElement childElement : childElements) {
				notificationTxt = notificationTxt + " "+ childElement.getText();
			}
			System.out.println(" Notfication Text: " + notificationTxt);
			resultDealPageload = notificationTxt;
		} else {
			System.out.println("Notification is not there ");
			//String urlToOrder = "https://www.pizzahut.co.in/order/deals/";
			//wait.until(ExpectedConditions.urlToBe(urlToOrder));
			resultDealPageload = driver.getCurrentUrl();
		}
		return resultDealPageload ;
	}//close-navigateOrderDealPage()
	
	

}
