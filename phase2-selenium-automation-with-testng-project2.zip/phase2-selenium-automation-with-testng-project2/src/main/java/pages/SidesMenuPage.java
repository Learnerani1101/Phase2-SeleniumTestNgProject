package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SidesMenuPage {
	WebDriver driver;
	WebDriverWait wait;

	public SidesMenuPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}

	/***************************************************************************
	 Go to sides and add any item 
	****************************************************************************/
	@FindBy(xpath = "//div[@class='basket-placeholder']")
	private WebElement elmBasket;
	
	@FindBy(xpath = "//span[@data-testid='sides']/div/a")
	private List<WebElement>elmSidesMenus ;
	
	public HashMap<String, Double> orderSideMenu(int numberOfSideItemsToAdd, double valPrinceRangeMax_SidesMenu,
			double valPrinceRangeMin_SidesMenu,String optionForOrder_SidesMenu) throws InterruptedException {
		boolean isSideMenuContainerPresent = elmBasket.isDisplayed();
		System.out.println("isSideMenuContainerPresent = "+isSideMenuContainerPresent);
		// Wait for all the menu to load
		Thread.sleep(Duration.ofSeconds(5));

		// Get Total Number of Items Under Sides Menu
		//String xpathSidesMenus = "//span[@data-testid='sides']/div/a";
		//List<WebElement> elmSidesMenus = driver.findElements(By.xpath(xpathSidesMenus));
		wait.until(ExpectedConditions.visibilityOfAllElements(elmSidesMenus));
		int totalSidesMenu = elmSidesMenus.size();
		System.out.println("Total Items under Sides Menu = " + totalSidesMenu);

		int counterSidesMenuAdd = 0;
		int indexSidesMenu = 0;
		String strSidesMenuPrice = "";
		double valSidesMenuPrice = 0;
		String strSidesMenuName = "";
		List<String> list1SidesMenu = new ArrayList<>();
		//List<String> list1SideMenyItemsInBasket = new ArrayList<>();
		HashMap<String, Double> hmSidesMenuAdded = new HashMap<>();
		int for_itr = 0;
		
		// Iterate through the side menu items
		for (WebElement childelmSidesMenus : elmSidesMenus) {
			for_itr = elmSidesMenus.indexOf(childelmSidesMenus);
			indexSidesMenu = for_itr + 1;
			
			// Get the price of the side menu item
			String xpathSidesMenuPrice = String.format("//span[@data-testid='sides']/div/a[%d]//button/span[2]",
					indexSidesMenu);
			//System.out.println("Generated xpathSidesMenuPrice: " + xpathSidesMenuPrice);
			WebElement elmSidesMenuPrice = driver.findElement(By.xpath(xpathSidesMenuPrice));
			strSidesMenuPrice = elmSidesMenuPrice.getText().replace("₹", "").trim();
			valSidesMenuPrice = Double.parseDouble(strSidesMenuPrice);
			//System.out.println("valSidesMenuPrice = " + valSidesMenuPrice);

			// Get the name of the sides menu item
			String xpathSidesMenuName = String.format("//span[@data-testid='sides']/div/a[%d]/div[2]", indexSidesMenu);
			//System.out.println("Generated xpathSidesMenuName: " + xpathSidesMenuName);
			WebElement elmSidesMenuName = driver.findElement(By.xpath(xpathSidesMenuName));
			strSidesMenuName = (elmSidesMenuName.getText().split("\n"))[0].trim();
			boolean checkNew_Sides = strSidesMenuName.contains("NEW");
			if (checkNew_Sides) {
				strSidesMenuName = strSidesMenuName.replace("NEW", "").trim();
			}
			//System.out.println("strSidesMenuName = " + strSidesMenuName);

			// Get the Add button for drink menu item
			String xpathSidesMenuAdd = String
					.format("//span[@data-testid='sides']/div/a[%d]//button[contains(.,'Add')]", indexSidesMenu);
			WebElement elmSidesMenuAddBtn = driver.findElement(By.xpath(xpathSidesMenuAdd));
			boolean isDisplayedSidesMenuAddBtn = elmSidesMenuAddBtn.isDisplayed();
			//System.out.println("isDisplayedSidesMenuAddBtn = " + isDisplayedSidesMenuAddBtn);

			// optionForOrder_SidesMenu = "OrderAccordingToPrice";
			switch (optionForOrder_SidesMenu.toLowerCase()) {
			case "orderaccordingtoprice":
				//System.out.println("Inside switch and case = " + optionForOrder_SidesMenu.toLowerCase());
		
				if ((valSidesMenuPrice<valPrinceRangeMax_SidesMenu )&&(valSidesMenuPrice>valPrinceRangeMin_SidesMenu)) {
					hmSidesMenuAdded.put(strSidesMenuName, valSidesMenuPrice);
					//list1SidesMenu.add(strSidesMenuName);
					wait.until(ExpectedConditions.elementToBeClickable(elmSidesMenuAddBtn));
					Thread.sleep(Duration.ofSeconds(2));
					elmSidesMenuAddBtn.click();
					counterSidesMenuAdd++;
					//System.out.println("Sides Menu added to checkout");
				} else {
					//System.out.println("Sides Menu NOT added to checkout");
				}

				break;
			case "OrderByMenu":
				System.out.println("Inside OrderByMenu");
				break;
			default:
				System.out.println("No Option was selected");
				break;
			} // end-switch
			//System.out.println("for_itr = " + for_itr + " and counterSidesMenuAdd = " + counterSidesMenuAdd);
			if (counterSidesMenuAdd == numberOfSideItemsToAdd) {
				break;
			}
			//System.out.println("===================================================================");
		} // for
		System.out.println("*********Print consolidated list of items which are ordered inside SideMenuPage Class*************** ");
		System.out.println("list1SidesMenu = " + list1SidesMenu);
		System.out.println("hmSidesMenuAdded = " + hmSidesMenuAdded);
		
		return hmSidesMenuAdded;

	}// end of orderSideMenu()
	
	
}
