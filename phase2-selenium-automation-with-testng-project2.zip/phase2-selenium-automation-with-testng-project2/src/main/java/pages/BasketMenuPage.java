package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasketMenuPage {
	WebDriver driver;
	WebDriverWait wait;

	public BasketMenuPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	}
	/***************************************************************************
	 Get the Items in Basket
	****************************************************************************/
	@FindBy(xpath= "//h2[contains(.,'Your Basket')]/following-sibling::div[@data-synth='basket-deal-item']")
	private List<WebElement> elmCheckOutBasketItems;
	
	public List<String> getTheItemsInBasket() {
		String itemsInBasket ;
		List<String> list2ItemsInBasket = new ArrayList<>();
		for (WebElement childBasketItems : elmCheckOutBasketItems) {
			//itemsInBasket = itemsInBasket+childBasketItems.getText();
			itemsInBasket = (((childBasketItems.getText()).split("₹"))[0]).trim();
			list2ItemsInBasket.add(itemsInBasket);
		}
		//Printing the Items Which is in Basket			 
		System.out.println("list2ItemsInBasket in BasketMenuPage Class= "+ list2ItemsInBasket); 
		return list2ItemsInBasket ;
	}
	/***************************************************************************
	 //Retrieve the Bill details i.e Total Bill , Tax and Amount Payable
	****************************************************************************/
	@FindBy(xpath="//div[@id='basket']/following-sibling::div/div[2]/div/div")
	private List<WebElement> elmBillContent;
	
	public List<String> getPriceDetailsFromCheckOutBasket() {
		List<String> priceDetailsFromBasket = new ArrayList<>();
		for (int i = 0; i < elmBillContent.size(); i++) {
            //System.out.println("Count is: " + i);
            priceDetailsFromBasket.add(elmBillContent.get(i).getText());
        }		
		/*
		String subTotal = elmBillContent.get(0).getText();
		String taxVal = elmBillContent.get(1).getText();
		String amountPayable = elmBillContent.get(2).getText();
		String priceDetails = subTotal+ "," +"\n" + taxVal+ "," +"\n" +amountPayable;
		*/
		return priceDetailsFromBasket;		
	}//end-getPriceDetailsFromCheckOutBasket()
	/*******************************************************************************************
	 //Retrieve the content of "CheckOut" Button and Validate it contain items count and price
	********************************************************************************************/
	@FindBy(xpath = "//div[@class='relative']/a/span")
	private List<WebElement> elmChkBtnContent ;
	
	@FindBy(xpath = "//div[@class='relative']/a")
	private WebElement elmChkButton;
	
	public String getCheckOutButtonContents() {
		//Add code to check if checkout button is enable
		boolean isCheckOutBtnEnable = elmChkButton.isEnabled();
		String strChkOutBtnInfo = "";
		String itemsCount = elmChkBtnContent.get(0).getText();
		String itemsPrice = elmChkBtnContent.get(2).getText();
		//System.out.println("itemsCount = " + itemsCount);
		//System.out.println(elmChkBtnContent.get(1).getText());
		//System.out.println("itemsPrice = " + itemsPrice);
		if(isCheckOutBtnEnable) {
			strChkOutBtnInfo = "CheckOut Button is enable and it contains"+"\n"+itemsCount+"\n"+itemsPrice; 
		}else {
			strChkOutBtnInfo = "CheckOut Button is disable" ;
		}
		return strChkOutBtnInfo;
		
	}//end -getCheckOutButtonContents()
	
	
	

}
