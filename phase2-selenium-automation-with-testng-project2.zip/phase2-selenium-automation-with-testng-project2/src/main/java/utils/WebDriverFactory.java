package utils;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverFactory {
	static WebDriver driver;

	public static WebDriver initDriver(String browser) {
		try {
			switch (browser) {
			case "chrome":
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver(createOptionsForChrome());
				// driver = new ChromeDriver();
				break;
			case "firefox":
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				break;
			case "edge":
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				break;
			}

		} catch (Exception e) {
			System.err.println("An error occurred:Stopping test " + e.getMessage());
			driver.quit();
		} finally {
			return driver;
		}

	} // close - initDriver

	public static ChromeOptions createOptionsForChrome() {
		// WebDriverManager.chromedriver().setup();
		// Create a HashMap to store the preferences
		Map<String, Object> prefs = new HashMap<>();
		// Configure the preference to block geolocation (2: block, 1: allow)
		// "profile.default_content_setting_values.geolocation": 2
		prefs.put("profile.default_content_setting_values.geolocation", 2);
		// Create an instance of ChromeOptions
		ChromeOptions options = new ChromeOptions();
		// Set the experimental option "prefs"
		options.setExperimentalOption("prefs", prefs);
		return options;
	}
} // close - class
