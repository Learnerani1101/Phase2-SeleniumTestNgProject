package utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportUtil {
	static ExtentReports report;
	static ExtentSparkReporter reporter ;
	static ExtentTest test;
		
	public static void setupReport() {
        // Get the project base directory
        String userDir = System.getProperty("user.dir");

        // Generate a timestamp
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

        // Define the report directory and file name
        String reportDirectoryPath = userDir + File.separator + "Reports";
        String reportFileName = "Report_" + timeStamp + ".html";

        // Ensure the "Reports" directory exists
        File reportDirectory = new File(reportDirectoryPath);
        if (!reportDirectory.exists()) {
            reportDirectory.mkdirs(); // Creates the directory if it doesn't exist
        }

        // Combine directory and file name
        String fullReportPath = reportDirectoryPath + File.separator + reportFileName;

        // Initialize ExtentReports and ExtentSparkReporter with the new path
        report = new ExtentReports();
        reporter = new ExtentSparkReporter(fullReportPath);
        report.attachReporter(reporter);
    }
	
	/*
	public static void setupreport_1() {
		report = new ExtentReports();
		reporter = new ExtentSparkReporter
			("D:\\eclipseworkspace-my-learning\\youtube-learnpomframework\\Reports\\Report.html");
		report.attachReporter(reporter);
	}*/
	
	public static ExtentTest starttest(String testname) {
		test = report.createTest(testname);
		return test;
	}
	
	public static void flushReport() {
		report.flush();
	}
	
}
