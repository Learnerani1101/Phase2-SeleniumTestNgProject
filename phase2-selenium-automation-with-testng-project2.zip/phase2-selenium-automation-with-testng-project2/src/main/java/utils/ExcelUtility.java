package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {
	FileInputStream fis;
	XSSFWorkbook wb ;
	XSSFSheet sheet ;
	
	public ExcelUtility(String excelFileName) {
		
		// Get the base directory path dynamically using user.dir
	    String PROJECT_DIR = System.getProperty("user.dir"); 
	    // Define the relative path to the Excel file
	    String EXCEL_RELATIVE_PATH = "//src//test//resources//"+excelFileName ;
	    System.out.println("EXCEL_RELATIVE_PATH :: "+EXCEL_RELATIVE_PATH);
	    // Combine them to form the absolute path
	    String EXCEL_PATH = PROJECT_DIR + EXCEL_RELATIVE_PATH;
	    System.out.println("EXCEL_PATH:: "+EXCEL_PATH);
	    //DataFormatter formatter = new DataFormatter();
		
		File file = new File(EXCEL_PATH);
		try {
			fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	// Retrieve data from excel and i/p params are :: int sheetNumber, int row , String nameOfColumn
	public String getData(int sheetNumber, int row , String nameOfColumn) {
		String targetColumnName = nameOfColumn.toLowerCase().trim() ;
		int columnIndex = 0;
		String cellValueAsString ="";
		sheet = wb.getSheetAt(sheetNumber);
		if (sheet == null) {
            throw new IllegalArgumentException("Sheet not found: " + "and sheetNumber = "+ sheetNumber);
        }
		
		Map<String, Integer> columnMap = getColumnIndexes(sheet);
		if (columnMap.containsKey(targetColumnName)) {
			columnIndex = columnMap.get(targetColumnName);
            System.out.println("The column index for '" + targetColumnName + "' is: " + columnIndex);
            // You can then use this index to access data in other rows
            // Row dataRow = sheet.getRow(1);
            // Cell targetCell = dataRow.getCell(columnIndex);
        } else {
            System.out.println("Column name '" + targetColumnName + " not found in sheet :" + sheetNumber); 
            throw new IllegalArgumentException("Column name" + targetColumnName + " not found in sheet :" + sheetNumber); 
        }
		if (sheet.getRow(row) == null) {
			System.out.println("row not found in sheet : " + sheetNumber + "and row value ="+ row); 
            throw new IllegalArgumentException("row not found in sheet : " + sheetNumber + "and row value ="+ row);          
        }
		Cell cell = sheet.getRow(row).getCell(columnIndex);
		DataFormatter formatter = new DataFormatter();
		if (cell != null) {
	        cellValueAsString = formatter.formatCellValue(cell);
	        System.out.println("Formatted value: " + cellValueAsString);
	    }else {
	    	System.out.println("cell not found in sheet : " + sheetNumber); 
	    	throw new IllegalArgumentException("cell not found in sheet: " + sheetNumber);
	    }
		//String data = sheet.getRow(row).getCell(columnIndex).getStringCellValue();
		return cellValueAsString;
		
	}
	
	public String getData(String sheetName, int row , String nameOfColumn) {
		String targetColumnName = nameOfColumn.toLowerCase().trim() ;
		int columnIndex = 0;
		String cellValueAsString ="";
		sheetName = sheetName.trim();
		sheet = wb.getSheet(sheetName);
		if (sheet == null) {
            throw new IllegalArgumentException("Sheet not found: " + sheetName);
        }
		
		Map<String, Integer> columnMap = getColumnIndexes(sheet);
		if (columnMap.containsKey(targetColumnName)) {
			columnIndex = columnMap.get(targetColumnName);
            System.out.println("The column index for '" + targetColumnName + "' is: " + columnIndex);
            // You can then use this index to access data in other rows
            // Row dataRow = sheet.getRow(1);
            // Cell targetCell = dataRow.getCell(columnIndex);
        } else {
            System.out.println("Column name '" + targetColumnName + " not found in sheet :" + sheetName); 
            throw new IllegalArgumentException("Column name" + targetColumnName + " not found in sheet :" + sheetName); 
        }
		if (sheet.getRow(row) == null) {
			System.out.println("row not found in sheet : " + sheetName + "and row value ="+ row); 
            throw new IllegalArgumentException("row not found in sheet : " + sheetName + "and row value ="+ row);          
        }
		Cell cell = sheet.getRow(row).getCell(columnIndex);
		DataFormatter formatter = new DataFormatter();
		if (cell != null) {
	        cellValueAsString = formatter.formatCellValue(cell);
	        System.out.println("Formatted value: " + cellValueAsString);
	    }else {
	    	System.out.println("cell not found in sheet : " + sheetName); 
	    	throw new IllegalArgumentException("cell not found in sheet: " + sheetName);
	    }
		//String data = sheet.getRow(row).getCell(columnIndex).getStringCellValue();
		return cellValueAsString;
	}
	/**
     * Reads the header row of an Excel sheet and creates a map of column names to their indices.
     *
     * @param sheet The Excel sheet.
     * @return A map where keys are column names (String) and values are column indices (Integer).
     */
    public static Map<String, Integer> getColumnIndexes(Sheet sheet) {
        Map<String, Integer> columnIndexes = new HashMap<>();
        // Assuming the header is in the first row (index 0)
        Row headerRow = sheet.getRow(0);

        if (headerRow != null) {
            for (Cell cell : headerRow) {
                // Use DataFormatter to handle different cell types if needed,
                // but for header names, getStringCellValue() usually works if they are strings.
                String columnName = cell.getStringCellValue().toLowerCase().trim();
                columnIndexes.put(columnName, cell.getColumnIndex());
            }
        }
        return columnIndexes;
    }
	public int getRowCount(int sheetNumber) {
		int row = wb.getSheetAt(sheetNumber).getLastRowNum();
		return row;
	}
	
	// Close the workbook and input stream when done
    public void closeExcelFile() throws IOException {
        if (wb != null) {
            wb.close();
        }
        if (fis != null) {
            fis.close();
        }
    }
}
