package base;

//This BaseTest is under phase2-selenium-automation-with-testng-project2

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;


import utils.TestConfigaretionReader;
//import utils.ConfigReader;
import utils.ExcelUtility;
import utils.ExtentReportUtil;
import utils.ScreenshotUtil;
import utils.WebDriverFactory;

public class BaseTest  {
	public WebDriver driver ;
	public ExtentTest test;
	public ExcelUtility excelUtil ;
	
	@BeforeTest
	@Parameters({"browser","env"})
	public void setup(String browser, String env) throws IOException {
		System.out.println("browser = "+ browser);
		System.out.println("env = "+env);		
		TestConfigaretionReader.readConfigPropertyFile();
		//public ExcelUtility excelUtil = new ExcelUtility("TestData.xlsx");
		excelUtil = new ExcelUtility(TestConfigaretionReader.getExcelFileName());
		
		driver = WebDriverFactory.initDriver(browser);
		driver.get(TestConfigaretionReader.getURL());
		driver.manage().window().maximize();
		ExtentReportUtil.setupReport();		
	}
	
	@BeforeMethod
	public void starttest(Method method) {
		test = ExtentReportUtil.starttest(method.getName());
	}
	
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {
		if(result.getStatus() == ITestResult.FAILURE ) {
			test.log(Status.FAIL, "Test Method is failed");
			ScreenshotUtil.getScreenshot(driver, result.getName());
		}
		if(result.getStatus() == ITestResult.SUCCESS ) {
			//getTest().info("Printing result for ::"+ result.getName());
			test.log(Status.PASS, "Test Method is Passed");
			//ScreenshotUtil.getScreenshot(driver, result.getName());
		}
	}
	
	@AfterTest
	@Parameters({"browser","env"})
	public void teardown(String browser, String env)throws IOException 
	{   
		excelUtil.closeExcelFile();
		test.info("Configaretion for the test"+ "<br>"+
				  "Browser = "+ browser+ "<br>"+
				  "Environment = "+ env + "<br>"+
				  "URL :"+ TestConfigaretionReader.getURL() + "<br>"+
				  "Test Data File :" + TestConfigaretionReader.getExcelFileName() );
		ExtentReportUtil.flushReport();
		driver.quit();
	}
	
}

