package testcases;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import base.BaseTest;
import pages.BasketMenuPage;
import pages.CheckOutPage;
import pages.DrinkMenuPage;
import pages.HomePage;
import pages.OrderDealPage;
import pages.SidesMenuPage;
import utils.ExcelUtility;

public class E2E_OrderItem_PizzaHut_DemoTest extends BaseTest {
	// WebDriver driver;
	// public ExcelUtility excelUtil = new ExcelUtility("TestData.xlsx");
	List<String> list1SideMenu = new ArrayList<>();
	List<String> list2DrinkMenu = new ArrayList<>();

	/*****************************************************************************************
	 * Verify If Application is launched
	 *****************************************************************************************/
	@Test(priority = 1)
	public void validateIfAPPLaunched() {
		String expectedAppUrl = excelUtil.getData("HomePage", 1, "AppURL");
		String actualAppUrl = driver.getCurrentUrl().trim();
		System.out.println("============Printing result for @Test = validateIfAPPLaunched()===============");
		test.info("Printing result for @Test = validateIfAPPLaunched()");
		System.out.println("expectedAppUrl = " + expectedAppUrl);
		System.out.println("actualAppUrl ==" + driver.getCurrentUrl());
		if (actualAppUrl.equals(expectedAppUrl)) {
			test.log(Status.PASS, "Application is launched sucessfully and URL is : " + actualAppUrl);
			System.out.println("equal");
		} else {
			test.log(Status.FAIL, "Application is not launched and URL of launched App : " + actualAppUrl);
			System.out.println("Not equal");
		}
	}// end - validateIfAPPLaunched()

	/*****************************************************************************************
	 * Verify that the user is now on the Deals page after entering delivery
	 *****************************************************************************************/
	@Test(priority = 2, dependsOnMethods = { "validateIfAPPLaunched" })
	public void validateIfOrderDealPageLoaded() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		System.out.println("===========Printing result for @Test = validateIfOrderDealPageLoaded()============");
		test.info("Printing result for @Test = validateIfOrderDealPageLoaded()");
		boolean ifBothDeliveryOptionPresent = homepage.checkBothDeliveryTabIsPresent();
		if (ifBothDeliveryOptionPresent) {
			test.log(Status.PASS, "Both Options of Delivery are present.");
			System.out.println("Both Options of Delivery are present");
		} else {
			test.log(Status.FAIL, "Options of Delivery were not present");
			System.out.println("Options of Delivery were not present");
		}
		String location = excelUtil.getData("HomePage", 1, "Location");
		// String location = "Tollygunge metro station";
		homepage.enterDeliveryLocation(location);
		String resultDealPageload = homepage.navigateOrderDealPage();
		String expectedUrlToOrder = excelUtil.getData("SidesMenuPage", 1, "DealPageURL");
		// String expectedUrlToOrder = "https://www.pizzahut.co.in/order/deals/";
		System.out.println("resultDealPageload = " + resultDealPageload);
		System.out.println("expectedUrlToOrder = " + expectedUrlToOrder);
		if (expectedUrlToOrder.equals(resultDealPageload)) {
			System.out.println("Order page is loaded");
			test.log(Status.PASS, "Order page is loaded and URL is :" + resultDealPageload);
			if (resultDealPageload.contains("deals")) {
				test.log(Status.PASS, "Order page URL contain Text 'deals'.");
			}
		} else {
			System.out.println("Order page is not loaded");
			test.log(Status.FAIL, "Order page is not loaded and available URL: " + resultDealPageload);
		}
	}// end - validateIfOrderPageLoaded()

	/*****************************************************************************************
	 * Click on menu "Sides" and Validate if Sides Menu Page is loaded
	 *****************************************************************************************/
	@Test(priority = 3, dependsOnMethods = { "validateIfOrderDealPageLoaded" })
	public void validateIfSideMenuPageLoaded() {
		OrderDealPage orderdealpage = new OrderDealPage(driver);
		test.info("Printing result for @Test = validateIfSideMenuPageLoaded()");
		System.out.println("=============Printing result for @Test = validateIfSideMenuPageLoaded()=============");
		String resultOfLoadingSideMenu = orderdealpage.selectMenuForOrder("Sides");
		// Validate if Sides Menu Page is loaded
		String expectedUrlForSidesMenu = "https://www.pizzahut.co.in/order/sides/";
		if (expectedUrlForSidesMenu.equals(resultOfLoadingSideMenu)) {
			test.log(Status.PASS, "Side Menu page is loaded and URL : " + resultOfLoadingSideMenu);
			System.out.println("Side Menu page is loaded.");
		} else {
			test.log(Status.FAIL, "Side Menu page is not loaded.");
			System.out.println("Side Menu page is not loaded.");
		}
	} // end - validateIfSideMenuPageLoaded

	/**************************************************************************************************
	 * Add item from "Sides" Menu and Verify if added - Go to sides and add any item
	 * that is below 200
	 **************************************************************************************************/
	@Test(priority = 4, dependsOnMethods = { "validateIfSideMenuPageLoaded" })
	public void addSidesMenuToOrderAndVerify() throws InterruptedException {
		SidesMenuPage sidesmenupage = new SidesMenuPage(driver);
		test.info("Printing result for @Test = addSidesMenuToOrderAndVerify()");
		System.out.println("=============Printing result for @Test = addSidesMenuToOrderAndVerify()==============");
		int numberOfSideItemsToAdd = Integer.parseInt(excelUtil.getData("SidesMenuPage", 1, "NumberOfSideItemsToAdd"));
		// int numberOfSideItemsToAdd = 1; // i/p param
		double valPrinceRangeMax_SidesMenu = Double
				.parseDouble(excelUtil.getData("SidesMenuPage", 1, "MaxPriceForSideMenuOrder"));
		// double valPrinceRangeMax_SidesMenu = 200.0; // i/p param
		double valPrinceRangeMin_SidesMenu = Double
				.parseDouble(excelUtil.getData("SidesMenuPage", 1, "MinPriceForSideMenuOrder"));
		// double valPrinceRangeMin_SidesMenu = 150; // i/p param
		String optionForOrder_SidesMenu = "OrderAccordingToPrice"; // i/p pram OrderAccordingToPrice
		HashMap<String, Double> hmSidesMenuAdded = sidesmenupage.orderSideMenu(numberOfSideItemsToAdd,
				valPrinceRangeMax_SidesMenu, valPrinceRangeMin_SidesMenu, optionForOrder_SidesMenu);
		double actualPriceSideMenu = 0;
		// Iterate using an enhanced for loop and entrySet()
		for (Map.Entry<String, Double> entry : hmSidesMenuAdded.entrySet()) {
			String item = entry.getKey(); // Get the key (item name)
			// Double price = entry.getValue(); // Get the value (price)
			actualPriceSideMenu = entry.getValue();
			System.out.println("Side Menu Added = " + item + ": ₹" + actualPriceSideMenu);
			test.info("Side Menu Added = " + item + ": ₹" + actualPriceSideMenu);
		}
		if (actualPriceSideMenu < valPrinceRangeMax_SidesMenu) {
			test.log(Status.PASS, "Actual Price of side menu = " + actualPriceSideMenu + " is less than "
					+ valPrinceRangeMax_SidesMenu);
			System.out.println("Actual Price of side menu = " + actualPriceSideMenu + " is less than "
					+ valPrinceRangeMax_SidesMenu);
		} else {
			test.log(Status.FAIL, "Actual Price of side menu = " + actualPriceSideMenu + " is not less than "
					+ valPrinceRangeMax_SidesMenu);
			System.out.println("Actual Price of side menu = " + actualPriceSideMenu + " is not less than "
					+ valPrinceRangeMax_SidesMenu);
		}

		// Create an ArrayList by extracting the keySet from the HashMap
		list1SideMenu = new ArrayList<>(hmSidesMenuAdded.keySet());

	}// end - addSidesMenuToOrderAndVerify()

	/**************************************************************************************************
	 * Validate that the product is added under Basket
	 **************************************************************************************************/
	@Test(priority = 5, dependsOnMethods = { "addSidesMenuToOrderAndVerify" })
	public void verifyAddedSidesMenuInBasketAndCheckOutInfo() {
		System.out.println("==============Printing result for @Test = verifyAddedSidesMenuInBasket()============");
		// System.out.println("list1SideMenu = " + list1SideMenu);
		BasketMenuPage basketmenupage = new BasketMenuPage(driver);
		List<String> list2ItemsInBasket = new ArrayList<>();
		list2ItemsInBasket = basketmenupage.getTheItemsInBasket();
		boolean contains = list1SideMenu.equals(list2ItemsInBasket);
		// Add a validation if Added items are present in basket
		if (contains) {
			List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();
			String priceDetails = priceDetailsFromBasket.toString();
			String str1 = "Added items are present in basket and price detail is::" + "\n"
					+ priceDetailsFromBasket.get(0) + "<br>" + priceDetailsFromBasket.get(1) + "<br>"
					+ priceDetailsFromBasket.get(2) + "<br>";

			System.out.println("Status.PASS, " + str1);
			test.log(Status.PASS, str1);
		} else {
			System.out.println("Added items are not present in basket");
		}
		String strChkOutBtnInfo = (basketmenupage.getCheckOutButtonContents()).toLowerCase().trim();
		if (strChkOutBtnInfo.contains("enable")) {
			test.log(Status.PASS, strChkOutBtnInfo);
			System.out.println("Status.PASS, " + strChkOutBtnInfo);
		} else {
			test.log(Status.FAIL, strChkOutBtnInfo);
			System.out.println("Status.FAIL, " + strChkOutBtnInfo);
		}

	}// end-verifyAddedSidesMenuInBasketAndCheckOutInfo()

	/**************************************************************************************************
	 * Click on menu "Drinks" and Validate if Drinks Menu Page is loaded
	 **************************************************************************************************/
	@Test(priority = 6)
	public void validateIfDrinkMenuPageLoaded() {
		OrderDealPage orderdealpage = new OrderDealPage(driver);
		test.info("Printing result for @Test = validateIfDrinkMenuPageLoaded()");
		System.out.println("==================Printing result for @Test = validateIfDrinkMenuPageLoaded()==========");
		String resultOfLoadingDrinkMenu = orderdealpage.selectMenuForOrder("Drinks");
		// Validate if Drinks Menu Page is loaded
		String expectedUrlForDrinkMenu = "https://www.pizzahut.co.in/order/drinks/";
		// String expectedurlForSidesMenu =
		// "https://www.pizzahut.co.in/order/"+menuChoice+"/";
		if (expectedUrlForDrinkMenu.equals(resultOfLoadingDrinkMenu)) {
			test.log(Status.PASS, "Drinks Menu page is loaded and URL of current page :: " + resultOfLoadingDrinkMenu);
			System.out.println("Drinks Menu page is loaded.");
		} else {
			test.log(Status.FAIL,
					"Drinks Menu page is not loaded and URL of current page :: " + resultOfLoadingDrinkMenu);
			System.out.println("Drinks Menu page is not loaded.");
		}
	} // end - validateIfDrinkMenuPageLoaded

	/**************************************************************************************************
	 * Add item from "Drinks" Menu and Verify if added Add any two drinks so that
	 * total cart pricing is more than 200
	 **************************************************************************************************/
	@Test(priority = 7, dependsOnMethods = { "validateIfDrinkMenuPageLoaded" })
	public void addDrinksMenuToOrderAndVerify() throws InterruptedException {
		DrinkMenuPage drinkmenupage = new DrinkMenuPage(driver);
		test.info("Printing result for @Test = addDrinksMenuToOrderAndVerify()");
		System.out.println("==========Printing result for @Test = addDrinksMenuToOrderAndVerify()==========");
		int numberOfDrinkItemToAdd = Integer.parseInt(excelUtil.getData("DrinkMenuPage", 1, "NumberOfDrinkItemsToAdd"));
		// int numberOfDrinkItemToAdd = 2;// ip param
		double valPrinceRangeMax_DrinksMenu = Double
				.parseDouble(excelUtil.getData("DrinkMenuPage", 1, "MaxPriceForDrinkMenuOrder"));
		// double valPrinceRangeMax_DrinksMenu = 60.0;// ip param
		double valPrinceRangeMin_DrinksMenu = Double
				.parseDouble(excelUtil.getData("DrinkMenuPage", 1, "MinPriceForDrinkMenuOrder"));
		// double valPrinceRangeMin_DrinksMenu = 0;// ip param
		String optionForOrder_DrinksMenu = "OrderAccordingToPrice";// ip param

		HashMap<String, Double> hmDrinkMenuAdded = drinkmenupage.orderDrinksMenu(numberOfDrinkItemToAdd,
				valPrinceRangeMax_DrinksMenu, valPrinceRangeMin_DrinksMenu, optionForOrder_DrinksMenu);
		System.out.println("============Printing HashMap hmDrinkMenuAdded Inside Login Test Class==================");
		if (hmDrinkMenuAdded.isEmpty()) {
			test.log(Status.FAIL, "Drink Items are not added");
		} else {
			// Iterate using an enhanced for loop and entrySet()
			for (Map.Entry<String, Double> entry : hmDrinkMenuAdded.entrySet()) {
				String item = entry.getKey(); // Get the key (item name)
				Double price = entry.getValue(); // Get the value (price)
				System.out.println("Drink Item Added = " + item + ": ₹" + price);
				test.log(Status.PASS, "Added Drink Item = " + item + ": ₹" + price);
			}
		}
		// Create an ArrayList by extracting the keySet from the HashMa
		list2DrinkMenu = new ArrayList<>(hmDrinkMenuAdded.keySet());

	}// end - addDrinksMenuToOrderAndVerify()

	/**************************************************************************************************
	 * After adding drink menu total cart pricing is more than 200
	 **************************************************************************************************/
	@Test(priority = 8, dependsOnMethods = { "addDrinksMenuToOrderAndVerify", "addSidesMenuToOrderAndVerify" })
	public void verify_Side_Drink_Menu_AddedInBasket() throws InterruptedException {
		BasketMenuPage basketmenupage = new BasketMenuPage(driver);

		test.info("Printing result for @Test = verify_Side_Drink_Menu_AddedInBasket()");
		System.out.println("=============Printing result for @Test = verify_Side_Drink_Menu_AddedInBasket()==========");

		String strExpectedAmountPayable = "200.00";
		double valExpectedAmountPayable = Double.parseDouble(strExpectedAmountPayable);

		List<String> priceDetailsFromBasket = basketmenupage.getPriceDetailsFromCheckOutBasket();

		String strAmount_V3 = ((priceDetailsFromBasket.getLast()).split("₹"))[1].trim();
		double actualAmountPayable = Double.parseDouble(strAmount_V3);
		List<String> list3ItemsInBasket = new ArrayList<>();
		list3ItemsInBasket = basketmenupage.getTheItemsInBasket();
		// combinedList now contains all elements from both lists
		List<String> list3CombinedMenu = new ArrayList<>(list1SideMenu);
		list3CombinedMenu.addAll(list2DrinkMenu);
		// Sort the items before comparing the lists as order of the elements are not
		// same in both the lists
		Collections.sort(list3CombinedMenu);
		Collections.sort(list3ItemsInBasket);

		String menuInfo = "Added items from sides and drinks menu are ::" + list3CombinedMenu + "<br>"
				+ "Items in Basket are::" + list3ItemsInBasket;
		// Compare Menu list with Basket List
		boolean isBasketContains = list3CombinedMenu.equals(list3ItemsInBasket);
		// Add a validation if Added items are present in basket
		if (isBasketContains) {
			System.out.println("Status.PASS, " + "Added items are present in basket ::" + "<br>" + menuInfo);
			test.log(Status.PASS, "Added items are present in basket ::" + "<br>" + menuInfo);
			if (actualAmountPayable > valExpectedAmountPayable) {
				test.log(Status.PASS,
						"Total Cart Pricing :: " + actualAmountPayable + " is more than " + valExpectedAmountPayable);
				System.out.println("Status.PASS " + "Total Cart Pricing ::" + actualAmountPayable + "is more than "
						+ valExpectedAmountPayable);
			}
		} else {
			test.log(Status.FAIL, "Added items are not present in basket ::" + "<br>" + menuInfo);
			System.out.println("Added items are not present in basket");
		}
	}// end-Verify_Side_Drink_Menu_AddedInBasket()

	/**************************************************************************************************
	 * Click on the Checkout button. The user will be navigated to the checkout page
	 **************************************************************************************************/
	@Test(priority = 9, dependsOnMethods = { "verify_Side_Drink_Menu_AddedInBasket" })
	public void verifCheckOutPageLoaded() throws InterruptedException {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = verifCheckOutPageLoaded()");
		System.out.println("================Printing result for @Test = verifCheckOutPageLoaded()==============");
		// Validate if CheckOut Page is loaded
		String expectedURLForCheckOut = "https://www.pizzahut.co.in/order/checkout/";
		String actualURLAfterCheckOut = checkoutpage.navigateToCheckOut();
		if (expectedURLForCheckOut.equals(actualURLAfterCheckOut)) {
			test.log(Status.PASS, "CheckOut page is loaded and URL of current page :: " + actualURLAfterCheckOut);
			System.out.println("CheckOut page is loaded.");
		} else {
			test.log(Status.FAIL, "CheckOut page is not loaded and URL of current page :: " + actualURLAfterCheckOut);
			System.out.println("CheckOut page is not loaded.");
		}
	}// end -verifCheckOutPageLoaded()

	/**************************************************************************************************
	 * Validate UPI RadioButton is selected by default in the checkout page
	 **************************************************************************************************/
	@Test(priority = 10, dependsOnMethods = { "verifCheckOutPageLoaded" })
	public void verifyUPIRadioButtonSelected() {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = verifyUPIRadioButtonSelected()");
		System.out.println("================Printing result for @Test = verifyUPIRadioButtonSelected()==============");
		boolean isUPISelected = checkoutpage.isUPIBtnSelected();
		if (isUPISelected) {
			System.out.println("Status.PASS, " + "isUPISelected = " + isUPISelected + "\n"
					+ " UPI RadioButton is  selected by default while completing payment for checkout");
			test.log(Status.PASS, "UPI RadioButton is selected by default while completing payment for checkout");
		} else {
			System.out.println("Status.FAIL, " + "isUPISelected = " + isUPISelected + "\n"
					+ "UPI RadioButton is not selected by default while completing payment for checkout");
			test.log(Status.FAIL, "UPI RadioButton is not selected by default while completing payment for checkout");
		}

	}// end - verifyUPIRadioButtonSelected

	/**************************************************************************************************
	 * Verify if Card option was selected while completing payment for checkout
	 **************************************************************************************************/
	@Test(priority = 11, dependsOnMethods = { "verifCheckOutPageLoaded", "verifyUPIRadioButtonSelected" })
	public void completePaymentByCard() throws InterruptedException {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = completePaymentByCard()");
		System.out.println("================Printing result for @Test = completePaymentByCard()==============");
		boolean isCardOptionSelected = checkoutpage.makePaymentWithCard();
		if (isCardOptionSelected) {
			System.out.println("Status.PASS, " + "isCardOptionSelected = " + isCardOptionSelected + "\n"
					+ " Card Option is selected for payment");
			test.log(Status.PASS, " Card Option is selected for payment");
		} else {
			System.out.println("Status.FAIL, " + "isCardOptionSelected = " + isCardOptionSelected + "\n"
					+ " Card Option is not selected for payment");
			test.log(Status.FAIL, " Card Option is not selected for payment");
		}
	}// end - completePaymentByCard
	/**************************************************************************************************
	 * Verify if Card option was selected while completing payment for checkout
	 **************************************************************************************************/
	@Test(priority = 12, dependsOnMethods = { "verifCheckOutPageLoaded"})
	public void verifyIAgreeCheckBoxIsChecked() {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = verifyIAgreeCheckBoxIsChecked()");
		System.out.println("================Printing result for @Test = verifyIAgreeCheckBoxIsChecked()==============");
		boolean isCheckedIAgreeCheckBox = checkoutpage.checkIfIAgreeChkBoxSelected();
		if (isCheckedIAgreeCheckBox) {
			System.out.println("Status.PASS, " + "isCheckedIAgreeCheckBox = " + isCheckedIAgreeCheckBox + "\n"
					+ " 'I Agree' CheckBox is selected by default in CheckOut Page");
			test.log(Status.PASS, " 'I Agree' CheckBox is selected by default in CheckOut Page");
		} else {
			System.out.println("Status.FAIL, " + "isCheckedIAgreeCheckBox = " + isCheckedIAgreeCheckBox + "\n"
					+ " 'I Agree' CheckBox is not selected by default in CheckOut Page");
			test.log(Status.FAIL, " 'I Agree' CheckBox is not selected by default in CheckOut Page");
		}

	}// end -verifyIAgreeCheckBoxIsChecked()
	/**************************************************************************************************
	 * Verify if Card option was selected while completing payment for checkout
	 **************************************************************************************************/
	@Test(priority = 13, dependsOnMethods = { "verifCheckOutPageLoaded","verifyIAgreeCheckBoxIsChecked"})
	public void enterCustomerDetailsToChkOut() {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = enterCustomerDetailsToChkOut()");
		System.out.println("===========Printing result for @Test = enterCustomerDetailsToChkOut()=========");
		String ipCustomerName = excelUtil.getData("CheckOutPage", 1, "CustomerName");
		//String ipCustomerName = "TestName1";
		String ipCustomerPhoneNum = excelUtil.getData("CheckOutPage", 1, "CustomerPhoneNum");
		//String ipCustomerPhoneNum = "9876543210";
		String ipCustomerEmail = excelUtil.getData("CheckOutPage", 1, "CustomerEmail");
		//String ipCustomerEmail = "TestEmail1@xyz.com";
		checkoutpage.enterCustomerInfoToChkOut(ipCustomerName, ipCustomerPhoneNum, ipCustomerEmail);
		String nameApp = checkoutpage.getCustomerNameFromApp().trim();

	}// end-enterCustomerDetailsToChkOut

	/**************************************************************************************************
	 * Click on Apply Gift Card and verify URL of Gift Card Dialogue
	 **************************************************************************************************/
	@Test(priority = 14, dependsOnMethods = { "verifCheckOutPageLoaded","enterCustomerDetailsToChkOut"})
	public void VerifyIfGiftCardApplied() throws InterruptedException {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = VerifyIfGiftCardApplied()");
		System.out.println("================Printing result for @Test = VerifyIfGiftCardApplied()==============");
		// Validate if Gift Card Dialogue is loaded
		String strToCheckinGiftCardURL = "showGiftCard";
		String actualURLGiftCard = checkoutpage.useGiftCard();
		if (actualURLGiftCard.contains(strToCheckinGiftCardURL)) {
			test.log(Status.PASS, "Gift Card Dialogue is loaded.");
			System.out.println("Gift Card Dialogue is loaded.");
		} else {
			test.log(Status.FAIL, "Gift Card Dialogue is not loaded.");
			System.out.println("Gift Card Dialogue is not loaded.");
		}
	}// end- VerifyIfGiftCardApplied()
	/**************************************************************************************************
	 * Apply for Coupon and verify error code is there if wrong coupon code is applied
	 **************************************************************************************************/
	@Test(priority = 15, dependsOnMethods = {"VerifyIfGiftCardApplied"})
	public void applyCoupon_CheckErrMsg() throws InterruptedException {
		CheckOutPage checkoutpage = new CheckOutPage(driver);
		test.info("Printing result for @Test = applyCoupon_CheckErrMsg()");
		System.out.println("============Printing result for @Test = applyCoupon_CheckErrMsg===========");
		String strCouponCode = excelUtil.getData("CheckOutPage", 1, "CouponCode");
		//String strCouponCode = "12345"; 
		String isErrCodePresent = checkoutpage.applyCoupon(strCouponCode);
		System.out.println("isErrCodePresent = "+ isErrCodePresent);
		if(isErrCodePresent.equals("")) {
			test.log(Status.FAIL, "There is no error code for wrong coupon code : "+strCouponCode);
		}else {
			String a = driver.getCurrentUrl();
			test.log(Status.PASS, "Error code ::" +isErrCodePresent +"<br>"+
					"for wrong coupon code : "+strCouponCode+ "<br>"+
					"current page url after cancelling coupon code :"+ a);
			System.out.println("current page url after cancelling coupon code :"+ a);
		}		
	}//end - applyCoupon_CheckErrMsg();
	/**************************************************************************************************
	 * Verify user back to basket page after canceling checkout due to wrong coupon code
	 **************************************************************************************************/
	@Test(priority = 16, dependsOnMethods = {"applyCoupon_CheckErrMsg"})
	public void verifyUserBackToBasketAfterCancellingCheckOut() {
		BasketMenuPage bmp = new BasketMenuPage(driver);
		System.out.println(
				"===================Printing result for @Test = verifyUserBackToBasketAfterCancellingCheckOut()===============");
		test.info("Printing result for @Test = verifyUserBackToBasketAfterCancellingCheckOut()");
		String currentUrl = driver.getCurrentUrl();
		String partialContent1 = "https://www.pizzahut.co.in/order/deals";
		if(bmp.getCheckOutButtonContents().contains("CheckOut Button is enable") 
				&& (currentUrl.contains(partialContent1))) {
			test.log(Status.PASS, "user is back to basket page after canceling checkout due to wrong coupon code"+"<br>"
				+ "and current page url is :: "+ currentUrl);
		}else {
			test.log(Status.FAIL, "user is not back to basket page after canceling checkout due to wrong coupon code"+"<br>"
					+ "and current page url is :: "+ currentUrl);
		}
	}


}// class - close